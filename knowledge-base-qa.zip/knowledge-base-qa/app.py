"""
企业知识库智能问答系统 — 后端
=============================
学习要点:
  1. RAG 完整流程: 文档解析 → 分块 → 向量化 → 检索 → 生成
  2. ChromaDB 向量数据库的使用
  3. 通过 OpenRouter 调用大语言模型
  4. FastAPI 构建 RESTful 接口
"""

import os, time, hashlib
from pathlib import Path
from typing import Dict, List

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
import chromadb
from chromadb.utils import embedding_functions
import httpx

# ═══════════════ 配置 (可通过环境变量覆盖) ═══════════════
API_KEY  = os.getenv("OPENROUTER_API_KEY", "nideapi")
API_BASE = os.getenv("LLM_BASE_URL",
                      "https://openrouter.ai/api/v1/chat/completions")
MODEL    = os.getenv("LLM_MODEL", "tencent/hy3-preview:free")
# 如果用龙猫等其他 OpenAI 兼容接口，改上面两个值即可

UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

# ═══════════════ 初始化 ═══════════════
app = FastAPI(title="知识库问答系统")

# ChromaDB: 轻量级向量数据库，数据存内存，重启需重新上传
# embedding 用的是 all-MiniLM-L6-v2 (本地模型，首次运行自动下载)
chroma    = chromadb.Client()
embed_fn  = embedding_functions.DefaultEmbeddingFunction()
"""
企业知识库智能问答系统 — 后端
=============================
学习要点:
  1. RAG 完整流程: 文档解析 → 分块 → 向量化 → 检索 → 生成
  2. ChromaDB 向量数据库的使用
  3. 通过 OpenRouter 调用大语言模型
  4. FastAPI 构建 RESTful 接口
"""

import os, time, hashlib
from pathlib import Path
from typing import Dict, List

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
import chromadb
from chromadb.utils import embedding_functions
import httpx

# ═══════════════ 配置 (可通过环境变量覆盖) ═══════════════
API_KEY  = os.getenv("OPENROUTER_API_KEY", "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")
API_BASE = os.getenv("LLM_BASE_URL",
                      "https://openrouter.ai/api/v1/chat/completions")
MODEL    = os.getenv("LLM_MODEL", "tencent/hy3-preview:free")
# 如果用龙猫等其他 OpenAI 兼容接口，改上面两个值即可

UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

# ═══════════════ 初始化 ═══════════════
app = FastAPI(title="知识库问答系统")

# ChromaDB: 轻量级向量数据库，数据存内存，重启需重新上传
# embedding 用的是 all-MiniLM-L6-v2 (本地模型，首次运行自动下载)
chroma    = chromadb.Client()
embed_fn  = embedding_functions.DefaultEmbeddingFunction()
kb = chroma.get_or_create_collection("knowledge_base", embedding_function=embed_fn)

# Token 用量统计 (对应申请表"日均消耗 Token")
stats = {"tokens": 0, "queries": 0}


# ═══════════════ 数据模型 ═══════════════
class Question(BaseModel):
    question: str


# ═══════════════ 核心函数 ═══════════════

def read_file(path: Path) -> str:
    """读取并解析文件内容"""
    ext = path.suffix.lower()
    if ext in (".txt", ".md", ".markdown"):
        return path.read_text("utf-8", errors="ignore")
    if ext == ".pdf":
        from PyPDF2 import PdfReader
        return "\n".join(
            p.extract_text() or "" for p in PdfReader(str(path)).pages
        )
    raise HTTPException(400, f"不支持的格式: {ext}，请用 .txt / .md / .pdf")


def split_text(text: str, max_chars: int = 500) -> List[str]:
    """
    智能分块: 优先按段落切分，超长段落按句子切分
    这是 RAG 中很关键的一步 — 分块质量直接影响检索效果
    """
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks: List[str] = []
    buf = ""

    for para in paragraphs:
        if len(buf) + len(para) + 2 <= max_chars:
            buf = f"{buf}\n\n{para}" if buf else para
        else:
            if buf:
                chunks.append(buf)
            # 超长段落按句号切分
            if len(para) > max_chars:
                parts = para.replace("。", "。\n").replace("！", "！\n") \
                            .replace("？", "？\n").split("\n")
                buf = ""
                for s in parts:
                    s = s.strip()
                    if not s:
                        continue
                    if len(buf) + len(s) + 1 <= max_chars:
                        buf = f"{buf}{s}" if buf else s
                    else:
                        if buf:
                            chunks.append(buf)
                        buf = s
            else:
                buf = para

    if buf:
        chunks.append(buf)
    return chunks or [text[:max_chars]]


async def ask_llm(prompt: str, system: str = "") -> tuple:
    """
    调用大语言模型
    返回: (回答文本, token用量)
    OpenRouter 的 API 格式与 OpenAI 完全兼容
    """
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    msgs.append({"role": "user", "content": prompt})

    async with httpx.AsyncClient(timeout=60) as http:
        r = await http.post(
            API_BASE,
            headers={"Authorization": f"Bearer {API_KEY}",
                     "Content-Type": "application/json"},
            json={"model": MODEL, "messages": msgs,
                  "temperature": 0.3, "max_tokens": 2000},
        )
        if r.status_code != 200:
            raise HTTPException(502, f"LLM 调用失败 ({r.status_code}): {r.text[:200]}")
        data = r.json()
        answer = data["choices"][0]["message"]["content"]
        tokens = data.get("usage", {}).get("total_tokens", 0)
        return answer, tokens


# ═══════════════ API 路由 ═══════════════

@app.get("/", response_class=HTMLResponse)
async def index():
    """返回前端页面"""
    return (Path(__file__).parent / "static" / "index.html").read_text("utf-8")


@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    """
    文档上传全流程: 保存 → 解析 → 分块 → 向量化 → 存入 ChromaDB
    """
    path = UPLOAD_DIR / file.filename
    path.write_bytes(await file.read())

    text   = read_file(path)
    chunks = split_text(text)
    doc_id = hashlib.md5(file.filename.encode()).hexdigest()[:8]

    # 存入向量数据库 (ChromaDB 会自动计算 embedding)
    kb.add(
        documents=chunks,
        ids=[f"{doc_id}_{i}" for i in range(len(chunks))],
        metadatas=[{"source": file.filename, "idx": i}
                   for i in range(len(chunks))],
    )
    return {"ok": True, "file": file.filename,
            "chunks": len(chunks), "chars": len(text)}


@app.get("/api/docs")
async def list_docs():
    """列出知识库中所有文档"""
    all_meta = kb.get()["metadatas"]
    doc_map: Dict[str, int] = {}
    for m in all_meta:
        doc_map[m["source"]] = doc_map.get(m["source"], 0) + 1
    return {"docs": [{"name": k, "chunks": v} for k, v in doc_map.items()],
            "total": sum(doc_map.values())}


@app.delete("/api/docs/{name}")
async def delete_doc(name: str):
    """删除指定文档"""
    found = kb.get(where={"source": name})
    if found["ids"]:
        kb.delete(ids=found["ids"])
    return {"ok": True, "deleted": len(found["ids"])}


@app.get("/api/stats")
async def get_stats():
    """获取 Token 用量统计"""
    return {"tokens": stats["tokens"], "queries": stats["queries"]}


@app.post("/api/chat")
async def chat(req: Question):
    """
    RAG 问答主流程 — 这是整个系统的核心
    三步链路: 向量检索 → 上下文组装 → LLM 生成
    """
    t0 = time.time()
    chain = []  # 记录 Agent 链路每一步的状态

    # ── Step 1: 向量检索 ──
    chain.append({"name": "向量检索", "icon": "🔍", "status": "done",
                   "detail": "在知识库中搜索相关片段..."})

    if kb.count() == 0:
        chain[-1]["detail"] = "知识库为空"
        return {"answer": "知识库为空，请先在左侧上传文档。",
                "sources": [], "chain": chain, "tokens": 0, "ms": 0}

    results = kb.query(query_texts=[req.question], n_results=5)
    sources = []
    for doc, meta, dist in zip(
        results["documents"][0],
        results["metadatas"][0],
        results["distances"][0],
    ):
        sources.append({
            "text": doc, "file": meta["source"],
            "score": round(max(0, 1 - dist), 2)
        })

    chain[-1]["detail"] = f"找到 {len(sources)} 个片段 | 最高相关度 {sources[0]['score']}"

    # ── Step 2: 上下文组装 ──
    chain.append({"name": "上下文组装", "icon": "🧩", "status": "done",
                   "detail": f"拼接 {sum(len(s['text']) for s in sources)} 字符上下文"})

    ctx = "\n\n---\n\n".join(
        f"[来源: {s['file']} | 相关度: {s['score']}]\n{s['text']}"
        for s in sources
    )

    # ── Step 3: LLM 生成 ──
    chain.append({"name": "智能生成", "icon": "✨", "status": "done",
                   "detail": "调用大语言模型生成回答..."})

    system = (
        "你是一个专业的知识库问答助手。严格基于参考资料回答，不编造内容。"
        "关键信息标注 [来源: 文件名]。如资料中无相关信息，明确说明。"
        "回答结构清晰，语言简洁。"
    )
    answer, tokens = await ask_llm(f"参考资料:\n{ctx}\n\n问题: {req.question}", system)

    stats["tokens"]  += tokens
    stats["queries"] += 1
    chain[-1]["detail"] = f"生成完成 | 消耗 {tokens} tokens"

    return {
        "answer":  answer,
        "sources": [{"file": s["file"], "score": s["score"],
                     "preview": s["text"][:150]} for s in sources],
        "chain":   chain,
        "tokens":  tokens,
        "ms":      round((time.time() - t0) * 1000),
    }


# ═══════════════ 启动 ═══════════════
if __name__ == "__main__":
    import uvicorn
    print("\n" + "=" * 50)
    print("  知识库智能问答系统 v1.0")
    print("  访问: http://localhost:8000")
    print("=" * 50 + "\n")
    uvicorn.run(app, host="0.0.0.0", port=8000)


# Token 用量统计 (对应申请表"日均消耗 Token")
stats = {"tokens": 0, "queries": 0}


# ═══════════════ 数据模型 ═══════════════
class Question(BaseModel):
    question: str


# ═══════════════ 核心函数 ═══════════════

def read_file(path: Path) -> str:
    """读取并解析文件内容"""
    ext = path.suffix.lower()
    if ext in (".txt", ".md", ".markdown"):
        return path.read_text("utf-8", errors="ignore")
    if ext == ".pdf":
        from PyPDF2 import PdfReader
        return "\n".join(
            p.extract_text() or "" for p in PdfReader(str(path)).pages
        )
    raise HTTPException(400, f"不支持的格式: {ext}，请用 .txt / .md / .pdf")


def split_text(text: str, max_chars: int = 500) -> List[str]:
    """
    智能分块: 优先按段落切分，超长段落按句子切分
    这是 RAG 中很关键的一步 — 分块质量直接影响检索效果
    """
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks: List[str] = []
    buf = ""

    for para in paragraphs:
        if len(buf) + len(para) + 2 <= max_chars:
            buf = f"{buf}\n\n{para}" if buf else para
        else:
            if buf:
                chunks.append(buf)
            # 超长段落按句号切分
            if len(para) > max_chars:
                parts = para.replace("。", "。\n").replace("！", "！\n") \
                            .replace("？", "？\n").split("\n")
                buf = ""
                for s in parts:
                    s = s.strip()
                    if not s:
                        continue
                    if len(buf) + len(s) + 1 <= max_chars:
                        buf = f"{buf}{s}" if buf else s
                    else:
                        if buf:
                            chunks.append(buf)
                        buf = s
            else:
                buf = para

    if buf:
        chunks.append(buf)
    return chunks or [text[:max_chars]]


async def ask_llm(prompt: str, system: str = "") -> tuple:
    """
    调用大语言模型
    返回: (回答文本, token用量)
    OpenRouter 的 API 格式与 OpenAI 完全兼容
    """
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    msgs.append({"role": "user", "content": prompt})

    async with httpx.AsyncClient(timeout=60) as http:
        r = await http.post(
            API_BASE,
            headers={"Authorization": f"Bearer {API_KEY}",
                     "Content-Type": "application/json"},
            json={"model": MODEL, "messages": msgs,
                  "temperature": 0.3, "max_tokens": 2000},
        )
        if r.status_code != 200:
            raise HTTPException(502, f"LLM 调用失败 ({r.status_code}): {r.text[:200]}")
        data = r.json()
        answer = data["choices"][0]["message"]["content"]
        tokens = data.get("usage", {}).get("total_tokens", 0)
        return answer, tokens


# ═══════════════ API 路由 ═══════════════

@app.get("/", response_class=HTMLResponse)
async def index():
    """返回前端页面"""
    return (Path(__file__).parent / "static" / "index.html").read_text("utf-8")


@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    """
    文档上传全流程: 保存 → 解析 → 分块 → 向量化 → 存入 ChromaDB
    """
    path = UPLOAD_DIR / file.filename
    path.write_bytes(await file.read())

    text   = read_file(path)
    chunks = split_text(text)
    doc_id = hashlib.md5(file.filename.encode()).hexdigest()[:8]

    # 存入向量数据库 (ChromaDB 会自动计算 embedding)
    kb.add(
        documents=chunks,
        ids=[f"{doc_id}_{i}" for i in range(len(chunks))],
        metadatas=[{"source": file.filename, "idx": i}
                   for i in range(len(chunks))],
    )
    return {"ok": True, "file": file.filename,
            "chunks": len(chunks), "chars": len(text)}


@app.get("/api/docs")
async def list_docs():
    """列出知识库中所有文档"""
    all_meta = kb.get()["metadatas"]
    doc_map: Dict[str, int] = {}
    for m in all_meta:
        doc_map[m["source"]] = doc_map.get(m["source"], 0) + 1
    return {"docs": [{"name": k, "chunks": v} for k, v in doc_map.items()],
            "total": sum(doc_map.values())}


@app.delete("/api/docs/{name}")
async def delete_doc(name: str):
    """删除指定文档"""
    found = kb.get(where={"source": name})
    if found["ids"]:
        kb.delete(ids=found["ids"])
    return {"ok": True, "deleted": len(found["ids"])}


@app.get("/api/stats")
async def get_stats():
    """获取 Token 用量统计"""
    return {"tokens": stats["tokens"], "queries": stats["queries"]}


@app.post("/api/chat")
async def chat(req: Question):
    """
    RAG 问答主流程 — 这是整个系统的核心
    三步链路: 向量检索 → 上下文组装 → LLM 生成
    """
    t0 = time.time()
    chain = []  # 记录 Agent 链路每一步的状态

    # ── Step 1: 向量检索 ──
    chain.append({"name": "向量检索", "icon": "🔍", "status": "done",
                   "detail": "在知识库中搜索相关片段..."})

    if kb.count() == 0:
        chain[-1]["detail"] = "知识库为空"
        return {"answer": "知识库为空，请先在左侧上传文档。",
                "sources": [], "chain": chain, "tokens": 0, "ms": 0}

    results = kb.query(query_texts=[req.question], n_results=5)
    sources = []
    for doc, meta, dist in zip(
        results["documents"][0],
        results["metadatas"][0],
        results["distances"][0],
    ):
        sources.append({
            "text": doc, "file": meta["source"],
            "score": round(max(0, 1 - dist), 2)
        })

    chain[-1]["detail"] = f"找到 {len(sources)} 个片段 | 最高相关度 {sources[0]['score']}"

    # ── Step 2: 上下文组装 ──
    chain.append({"name": "上下文组装", "icon": "🧩", "status": "done",
                   "detail": f"拼接 {sum(len(s['text']) for s in sources)} 字符上下文"})

    ctx = "\n\n---\n\n".join(
        f"[来源: {s['file']} | 相关度: {s['score']}]\n{s['text']}"
        for s in sources
    )

    # ── Step 3: LLM 生成 ──
    chain.append({"name": "智能生成", "icon": "✨", "status": "done",
                   "detail": "调用大语言模型生成回答..."})

    system = (
        "你是一个专业的知识库问答助手。严格基于参考资料回答，不编造内容。"
        "关键信息标注 [来源: 文件名]。如资料中无相关信息，明确说明。"
        "回答结构清晰，语言简洁。"
    )
    answer, tokens = await ask_llm(f"参考资料:\n{ctx}\n\n问题: {req.question}", system)

    stats["tokens"]  += tokens
    stats["queries"] += 1
    chain[-1]["detail"] = f"生成完成 | 消耗 {tokens} tokens"

    return {
        "answer":  answer,
        "sources": [{"file": s["file"], "score": s["score"],
                     "preview": s["text"][:150]} for s in sources],
        "chain":   chain,
        "tokens":  tokens,
        "ms":      round((time.time() - t0) * 1000),
    }


# ═══════════════ 启动 ═══════════════
if __name__ == "__main__":
    import uvicorn
    print("\n" + "=" * 50)
    print("  知识库智能问答系统 v1.0")
    print("  访问: http://localhost:8000")
    print("=" * 50 + "\n")
    uvicorn.run(app, host="0.0.0.0", port=8000)
